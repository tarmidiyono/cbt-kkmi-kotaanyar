# 📋 PANDUAN INSTALASI — CBT KKMI KOTAANYAR (Versi API)

Arsitektur baru: **Frontend** (HTML/CSS/JS) di **GitHub Pages**, **Backend** = Google Apps Script sebagai REST API JSON (data tetap di Google Sheets).

```
Browser siswa/guru/admin ──fetch──►  GitHub Pages (tampilan)
                         └─fetch──►  Apps Script /exec (API JSON) ──► Google Sheets + Drive
```

---

## BAGIAN A — BACKEND (Google Apps Script)

### A1. Sudah pernah memasang versi sebelumnya (migrasi)

Data Sheets dan akun Anda **tidak hilang** — tersimpan di Script Properties & Spreadsheet.

1. Buka proyek Apps Script lama.
2. **Hapus** 3 file HTML: `Index`, `Stylesheet`, `JavaScript` (titik tiga → Delete). Backend baru tidak memakainya lagi.
3. Ganti seluruh isi file skrip (`Code`/`Kode`) dengan `Kode.gs` yang baru.
4. Project Settings → *Show appsscript.json* → pastikan isinya sama dengan `appsscript.json` yang baru.
5. **Jangan perlu** menjalankan `setupAppEnvironment` lagi (aman bila dijalankan, tidak menimpa data).
6. **Deploy → Manage deployments → ✏️ (Edit) → Version: *New version* → Deploy.**
   URL `/exec` **tetap sama**. Lupa memilih *New version* adalah penyebab paling umum "perubahan tidak berlaku".

### A2. Pemasangan baru

1. <https://script.google.com> → **Proyek baru**.
2. Tempel `Kode.gs` ke file skrip; isi `appsscript.json` seperti di atas (Project Settings → Show appsscript.json).
3. Pilih fungsi **`setupAppEnvironment`** → ▶ Run → izinkan akses. **Jalankan sekali.**
4. Buka **Executions/Logs**, catat: link Spreadsheet, link folder Drive, **akun awal + sandi** (hanya tampil sekali) dan token ujian contoh.
5. Jalankan **`pasangTriggerFinalisasi`** sekali.
6. **Deploy → New deployment → Web app** → Execute as: **Me** · Who has access: **Anyone** → Deploy → **salin URL `/exec`**.

### A3. Uji backend

Buka di browser: `URL_EXEC?action=ping` → harus tampil JSON seperti
`{"success":true,"data":{"app":"CBT KKMI KOTAANYAR","versi":"2.0-api", ...}}`.
Kalau muncul halaman login Google / HTML → akses deployment belum **Anyone** atau belum *New version*.

---

## BAGIAN B — FRONTEND (GitHub Pages)

### B1. Siapkan folder kerja

1. **Extract** `cbt-kkmi-kotaanyar-frontend.zip` (klik kanan → *Extract All*).
2. Folder hasil ekstrak **itulah folder kerja Anda** — folder yang nanti di-`git init`. Jangan masuk lebih dalam, jangan naik satu level. Isinya harus langsung:

```
index.html     ← harus terlihat langsung di folder ini
css/style.css
js/config.js   ← SATU-SATUNYA file yang diedit
js/core.js  js/views-admin.js  js/views-siswa.js  js/app.js
README.md  PANDUAN-INSTALASI.md  .nojekyll
```

### B2. Isi alamat backend (WAJIB sebelum push)

Buka `js/config.js` dengan Notepad, ganti tulisan `GANTI_DENGAN_URL_EXEC_DARI_APPS_SCRIPT` dengan URL `/exec` dari langkah A:

```js
const CFG = { GAS_URL: 'https://script.google.com/macros/s/AKfyc.../exec' };
```

### B3. Install Git, akun, identitas

- Windows: <https://git-scm.com/download/win> (pengaturan default). Mac: ketik `git --version` di Terminal. Cek: `git --version`.
- Akun: <https://github.com> (username menjadi bagian alamat situs: `username.github.io`).
- Identitas (sekali per komputer):

```bash
git config --global user.name "Nama Anda"
git config --global user.email "email-akun-github@contoh.com"
```

### B4. Buat repository

github.com → **+** → **New repository** → nama mis. `cbt-kkmi-kotaanyar` → **Public** → **jangan** centang README/.gitignore/license → Create.

### B5. Buka terminal di folder kerja & VERIFIKASI

Windows: buka folder kerja di File Explorer → klik address bar → ketik `powershell` → Enter.

```powershell
dir
```

**Gerbang wajib:** `index.html`, folder `css`, dan folder `js` harus terlihat. Jika yang terlihat justru folder lain (mis. `cbt-kkmi-kotaanyar-frontend`), Anda satu level terlalu tinggi → `cd` ke dalamnya dulu. Jangan ada file `.gs` di sini.

### B6. Push pertama (satu per satu)

```bash
git init
git add .
git commit -m "Upload pertama"
git branch -M main
git remote add origin https://github.com/USERNAME/cbt-kkmi-kotaanyar.git
git push -u origin main
```

(`git add .` — ada **titik** di akhir.) Saat diminta *Password*, tempel **Personal Access Token** (bukan password akun). Layar **tidak menampilkan karakter apa pun** saat mengetik/paste — itu normal; tekan Enter.

**Membuat token:** <https://github.com/settings/tokens> → *Generate new token (classic)* → centang **repo** → Generate → salin `ghp_…` (hanya tampil sekali). Alternatif tanpa token: **GitHub Desktop** (<https://desktop.github.com>).

> Jangan upload lewat tombol "Add file → Upload files" di web GitHub — struktur folder `css/` dan `js/` jadi rata dan situs rusak (CSS/JS 404).

Sukses bila muncul `* [new branch] main -> main`.

### B7. Aktifkan Pages

Repo di GitHub → **Settings → Pages** → Source: **Deploy from a branch** → Branch **main** · **/ (root)** → Save → centang **Enforce HTTPS**. Tunggu 1–2 menit → situs di `https://USERNAME.github.io/cbt-kkmi-kotaanyar/`.

### B8. Update di kemudian hari

```bash
git add .
git commit -m "Deskripsi perubahan"
git push
```
Jika tampilan lama masih muncul: **Ctrl+Shift+R**.

---

## BAGIAN C — UJI AKHIR

1. Buka situs GitHub Pages → layar login menampilkan nama aplikasi dari server (tanda backend terhubung).
2. Login admin → dashboard tampil. Login siswa demo → tab *Siswa*.
3. F12 → Console/Network: tidak boleh ada error CORS atau 404.
4. Uji ujian demo di HP & komputer.

## Troubleshooting

| Gejala | Penyebab | Solusi |
|---|---|---|
| Login menampilkan "URL backend belum diatur" | `js/config.js` belum diisi | Isi `GAS_URL`, lalu `git add . && git commit -m fix && git push` |
| "Server tidak membalas JSON…" | Deployment bukan *Anyone* / belum *New version* | A1 langkah 6 / A2 langkah 6 |
| Error CORS di Console | Header POST bukan `text/plain`, atau URL bukan `/exec` | Jangan ubah `js/core.js`; pakai URL berakhiran `/exec` (bukan `/dev`) |
| 404 di situs | `index.html` tidak di root repo | Buka repo di GitHub: jika terlihat folder pembungkus, push ulang dari folder yang benar (`git push -u origin main --force`) |
| Situs tanpa gaya/CSS | Folder `css/` `js/` tidak terjaga | Push ulang dari terminal, jangan upload via web |
| `Password authentication is not supported` | GitHub butuh token | Langkah B6 (token) |
| "Sistem sedang sibuk" saat banyak siswa | Antrian tulis ke Sheets | Mulai ujian bergelombang per ruang |
| Respons pertama lambat (~2–5 dtk) | GAS "dingin" | Normal; layar login sudah memanaskan server otomatis |
